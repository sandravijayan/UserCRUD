<?php
class DbConnect {

	function __construct() 
	{
		$this->dbconnect();
	}

	/**
	* function for database connection.
	*
	* @return $conn
	* @throws \Exception
	*/
	function dbconnect() 
	{
	    try{
			require_once 'config.php';
			$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABSE);
			// test the connection is established or not
			if (mysqli_connect_error()) {
				die("Connection Error.");
			}
			return $conn;
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	/**
	* function for closing database connection.
	*/
	public function close() 
	{
		mysqli_close();
	}
}
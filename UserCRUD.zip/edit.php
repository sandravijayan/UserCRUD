
<?php

	require_once 'DbConnect.php';
	$conn = new DbConnect();
	$db = $conn->dbconnect();
	$id = $_REQUEST['id'];
	$array = mysqli_query($db,'SELECT a.user_id, a.name, a.email, a.file, b.address FROM user a LEFT JOIN address b ON a.user_id = b.user_id WHERE a.user_id ='.$id)or die("unable to fetch data");
	$result = mysqli_fetch_array($array);
	// $id = $_REQUEST['id'];
	// $query = "SELECT * from new_record where id='".$id."'"; 
	// $result = mysqli_query($con, $query) or die ( mysqli_error());
	// $row = mysqli_fetch_assoc($result);
	// print_r($result);die;
?>

<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8" />
    <title>Edit User Details</title>
    <link rel="stylesheet" type="text/css" href="assets/bootstrap.css" />
</head>

<body>
    <div class="container">
        <section>
            <div id="container_demo">
                <a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                    <div id="edit" class="col-md-6">
                        <form method="post" name="edit" action="">
                            <h1 align="center">Edit User Details</h1>
                            <div class="form-group">
                                <label for="username" class="youname" data-icon="e">Name</label>
                                <input id="username" name="name" value = "<?php echo $result[1];?>" required="required" type="name" class="form-control" />
                            </div>
                            <div class="form-group">
                                <label for="emailsignup" class="youmail" data-icon="e">Email</label>
                                <input id="emailsignup" name="email" value = "<?php echo $result[2];?>" required="required" type="email" class="form-control" />
                            </div>
                            <div class="form-group">
                                <label for="useraddress" class="youaddress" data-icon="p">Address</label>
                                <input id="useraddress" name="address" value = "<?php echo $result[4];?>" required="required" type="address" class="form-control" />
                            </div>
                            <div class="form-group">
                                <label for="userfile" class="youfile" data-icon="p">File</label>
                                <input id="userfile" name="file" value = "<?php echo $result[3];?>" required="required" type="file" class="form-control" />
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="edit" value="Submit" /> ViewUser? <a href="viewuser.php">click here</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
</body>
</html>

<?php
include_once 'UserFunction.php';

$funObj = new UserFunction();

if (!empty($_POST['edit']) && $_POST['edit']) 
{
	$userid = $_REQUEST['id'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	$file = $_POST['file'];
	$userUpdate = $funObj->userUpdate($userid, $name, $email, $address, $file);
	if ($userUpdate) 
    {
		// If updation success then go to view page.
		echo "<script>alert('Updated Successfully')</script>";
		header("location:viewuser.php");

	} else {
		// If updation failed return error message.
		echo "<script>alert('Failed to update')</script>";
	}
}


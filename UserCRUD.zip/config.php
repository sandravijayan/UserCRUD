<?php
//set constants for database congigurations.
define("DB_HOST", 'localhost');
define("DB_USER", 'root');
define("DB_PASSWORD", '');
define("DB_DATABSE", 'user');
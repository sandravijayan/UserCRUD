<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ADD PLAY SCHOOLS</title>
</head>
<body bgcolor="#FFFFFF">
<font color="#000000" face="Baskerville, Palatino Linotype, Palatino, Century Schoolbook L, Times New Roman, serif" size="+2">
<h2 align="center">VIEW USERS</h2>
<?php

	require_once 'DbConnect.php';
	$conn = new DbConnect();
	$db = $conn->dbconnect();
	$sql = mysqli_query($db,'SELECT a.user_id, a.name, a.email, a.file, b.address FROM user a,address b WHERE a.user_id = b.user_id') or die("cannot connect");
	
?>
<form name="viewcOMPLAINT" enctype="multipart/form-data"/>
<font color="##000000" face="Baskerville, Palatino Linotype, Palatino, Century Schoolbook L, Times New Roman, serif" size="+1"/>
<table align="center" cellpadding="10" cellspacing="10" border="2" bordercolor="##000000">
<tr><th>ID</th><th>NAME</th><th>EMAIL</th><th>FILE</th><th>ADDRESS</th><th colspan=2>ACTION</th></tr>
<?php
while($array=mysqli_fetch_array($sql))
{
	    print "<tr> <td>";
        echo $array[0];

        print "</td> <td>";
        echo $array[1]; 

		print "</td> <td>";
        echo $array[2];

		print "</td> <td>";
		echo $array[3];

		print "</td> <td>";
        echo $array[4];

        print "</td><td>";
		echo '<a href="edit.php?id='.$array[0].'";">Edit</a>';

		print "</td><td>";
		echo '<a href="delete.php?id='.$array[0].'"onclick="return confirm('."'Are you sure?'".');">Delete</a>';
		print "</td> </tr>";
}
?>

</table>
</font>
</form>
<p align="center"> Add User?<a href="index.php">click here</a>
</html>
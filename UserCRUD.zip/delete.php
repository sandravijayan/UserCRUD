
<?php

	// require_once 'DbConnect.php';
	// $conn = new DbConnect();
	// $db = $conn->dbconnect();
	// $id = $_REQUEST['id'];
	// $deleteUser = mysqli_query($db,'DELETE FROM user WHERE user_id ='.$id)or die("unable to fetch data");
	// if ($deleteUser) {
	// 	$deleteAddress = mysqli_query($db,'DELETE FROM address WHERE user_id ='.$id)or die("unable to fetch data");
	// }
	// $result = mysqli_fetch_array($array);

    include_once 'UserFunction.php';
	$funObj = new UserFunction();
	$userid = $_REQUEST['id'];
	$userDelete = $funObj->userDelete($userid);
	if ($userDelete) 
    {
		// If updation success then go to view page.
		echo "<script>alert('User Details Deleted Successfully')</script>";
		header("location:viewuser.php");

	} else {
		// If updation failed return error message.
		echo "<script>alert('Failed to update')</script>";
	}
	
?>
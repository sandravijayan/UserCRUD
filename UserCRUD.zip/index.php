<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8" />
    <title>Create User</title>
    <link rel="stylesheet" type="text/css" href="assets/bootstrap.css" />
</head>

<body>
    <div class="container">
        <section>
            <div id="container_demo">
                <a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                    <div id="register" class="col-md-6">
                        <form method="post" name="register" action="">
                            <h1 align="center">Create User</h1>
                            <div class="form-group">
                                <label for="username" class="youname" data-icon="e">Name</label>
                                <input id="username" name="name" required="required" type="name" class="form-control" />
                            </div>
                            <div class="form-group">
                                <label for="emailsignup" class="youmail" data-icon="e">Email</label>
                                <input id="emailsignup" name="email" required="required" type="email" class="form-control" />
                            </div>
                            <div class="form-group">
                                <label for="useraddress" class="youaddress" data-icon="p">Address</label>
                                <input id="useraddress" name="address" required="required" type="address" class="form-control" />
                            </div>
                            <div class="form-group">
                                <label for="userfile" class="youfile" data-icon="p">File</label>
                                <input id="userfile" name="file" required="required" type="file" class="form-control" />
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="register" value="Submit" /> ViewUser? <a href="viewuser.php">click here</a>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
</body>

</html>
<?php
include_once 'UserFunction.php';

$funObj = new UserFunction();

if (isset($_POST['register']) && $_POST['register']) 
{
	$name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $file = $_POST['file'];
    // move_uploaded_file($_FILES["file"]["tmp_name"],"upload/".$_FILES["file"]["name"]);
    // $path="upload/".$_FILES["file"]["name"];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);
    move_uploaded_file($_FILES["file"]["name"], $target_file);
	$user = $funObj->userRegister($name, $email, $address, $file);
	if ($user) {
		// If user creation success then go to view page.
		header("location:viewuser.php");
	} else {
		// If user creation failed return error message.
		echo "<script>alert('User Creation Failed')</script>";
	}
}
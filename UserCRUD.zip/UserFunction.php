<?php
require_once 'DbConnect.php';
session_start();

class UserFunction 
{

	private $db;

	function __construct() 
	{
		// connecting to the database
		$conn = new DbConnect();
		$this->db = $conn->dbconnect();
	}

	/**
	* function for user registration 
	* @param string $email, $firstname, $lastname, $password, $dob
	* @return $query
	* @throws \Exception
	*/
	public function userRegister($name, $email, $address, $file) 
	{
		try {
			$query = mysqli_query($this->db, sprintf("INSERT INTO user(name,email,file) values('%s','%s','%s')", $name, $email,$file)) or die(mysql_error());
			$last_id = mysqli_insert_id($this->db);
			if ($query) {
				$userid = $last_id;
				$query2 = mysqli_query($this->db, sprintf("INSERT INTO address(address,user_id) values('%s','%s')", $address, $userid)) or die(mysql_error());
			}
			return $query2;
		} catch (\Exception $e) {
			return $e->getMessage();
		}
	}

	/**
	* function for update user data.
	* @param string $email, $firstname, $lastname, $password, $dob
	* @param int $userId
	* @return boolean
	* @throws \Exception
	*/
	public function userUpdate($userid, $name, $email, $address, $file)
	{
		try {
			
			$update = "UPDATE user SET name ='".$name."',email ='".$email."', file ='".$file."' WHERE user_id=".$userid."";
			$updateUser = mysqli_query($this->db, $update) or die(mysqli_error());
			if ($updateUser) {
				$query = "UPDATE address SET address ='".$address."' WHERE user_id=".$userid."";
				$updateAddress = mysqli_query($this->db, $query) or die(mysqli_error());
			}
			return $updateAddress;
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	/**
	* function for deleting user.
	* @param string $email, $password
	* @return 
	* @throws \Exception
	*/
	public function userDelete($userid)
	{
		try {
			$delete = "DELETE FROM user WHERE user_id =".$userid;
			$deleteUser = mysqli_query($this->db, $delete)or die("unable to fetch data");
			if ($deleteUser) {
				$deletenext = 'DELETE FROM address WHERE user_id ='.$userid;
				$deleteAddress = mysqli_query($this->db, $deletenext)or die("unable to fetch data");
			}
			return $deleteAddress;
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	/**
	* function for login.
	* @param string $email
	* @return boolean
	* @throws \Exception
	*/
	public function isUserExist($email) 
	{
		try {
			$result = mysqli_query($this->db, sprintf("SELECT * FROM user WHERE email = '%s'", $email));
			//get the number of rows returned
			$row = mysqli_num_rows($result);

			if ($row > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}
}